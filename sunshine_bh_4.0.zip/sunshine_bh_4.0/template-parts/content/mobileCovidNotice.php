<section class="mobile_covid_notice_section hide_on_desktop">
    <div class="mobile_covid_notice_container">
        <a href="/our-response-to-the-corona-virus-health-concern/">Our Response to COVID-19</a>
    </div>
</section>