<?php if (!get_field('hide_disclosure_and_cta')) : ?>
    <section class="page_treatment_cta">
        <h4>Talk with one of our Treatment Specialists!</h4>
        <p>Call 24/7: <a id="bottomPagePhone" class="invocaNumber bottomPagePhone" onclick="dataLayer.push({'event': 'phone_click', 'shortcode_type' : 'bottomPagePhone'});" href="tel:949-276-2886"> 949-276-2886</a></p>
    </section>
<?php endif; ?>