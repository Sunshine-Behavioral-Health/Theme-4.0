<section class="a-b-test a-b-test--buttons extra-class two_buttons_cta_section shortcode_section">
    <div class="two_buttons_cta_container">
        <div class="shortcode_two_buttons_cta shortcode_two_buttons_first_cta">
            <a href="tel:949-276-2886" id="twoLongButtonCtaPhone" class="invocaNumber twoLongButtonCtaPhone" onclick="dataLayer.push({'event': 'phone_click', 'shortcode_type' : 'twoLongButtonCtaPhone'});">Talk with a treatment specialist 24/7 – Call 949-276-2886</a>
        </div>
        <div class="shortcode_two_buttons_cta shortcode_two_buttons_second_cta">
            <a class="twoLongButtonCtaInsurance" onclick="dataLayer.push({'event': 'insurance_click', 'shortcode_type' : 'twoLongButtonCtaInsurance'});" href="https://www.sunshinebehavioralhealth.com/insurance/">Check your insurance coverage</a>
        </div>
    </div>
</section>