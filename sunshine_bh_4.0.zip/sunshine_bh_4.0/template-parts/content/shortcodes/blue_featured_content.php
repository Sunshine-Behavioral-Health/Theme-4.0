<section class="blue_featured_content_section shortcode_section">
    <div class="blue_featured_content_container">
        <div class="blue_featured_content_headline">
            <h2><?php echo get_field('blue_featured_content_headline') ?></h2>
        </div>
        <div class="blue_featured_content_body list_styling">
            <?php echo get_field('blue_featured_content_body_content') ?>
        </div>
    </div>
</section>