

<section class="content-with-border">
    <div class="wrapper content-with-border--container">
        <?= get_field('content_with_border--content') ?>
    </div>
</section>