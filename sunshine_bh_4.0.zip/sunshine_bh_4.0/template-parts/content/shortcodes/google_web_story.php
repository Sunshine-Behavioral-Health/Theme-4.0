<section class="google_web_story_section">
    <div class="google_web_story_container">
        <iframe src="<?php echo get_field('google_web_story-url') ?>" width="366" height="653"></iframe>
    </div>
</section>