<section class="headline_and_button_sidebar_shortcode_section hide_on_mobile">
    <h4>Not sure how to Pay for Treatment?</h4>
    <div class="headline_and_button_cta"><a href="/insurance/" id="payForTreatment" class="payForTreatment">Check Your Insurance</a></div>
</section>