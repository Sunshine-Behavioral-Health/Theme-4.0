<section class="learn_centers_sidebar_section learnRehabCenters" id="learnRehabCenters">
    <div class="learn_centers_center_container">
        <img src="<?php echo get_template_directory_uri() . '/images/sidebar/1top-side-bar-.jpg' ?>" alt="" loading="lazy">

        <a href="/our-rehab-centers/chapters-capistrano/"><img src="<?php echo get_template_directory_uri() . '/images/sidebar/2chapters-side-bar.jpg' ?>" alt="" loading="lazy"></a>

        <a href="/our-rehab-centers/monarch-shores/"><img src="<?php echo get_template_directory_uri() . '/images/sidebar/3-monarch-side-bar.jpg' ?>" alt="" loading="lazy"></a>

        <a href="/our-rehab-centers/mountain-springs-recovery/"><img src="<?php echo get_template_directory_uri() . '/images/sidebar/4mountains-side-bar.jpg' ?>" alt="" loading="lazy"></a>

        <a href="/our-rehab-centers/willow-springs-recovery/"><img src="<?php echo get_template_directory_uri() . '/images/sidebar/willow_sidebar.png' ?>" alt="" loading="lazy"></a>

        <a href="/our-rehab-centers/lincoln-recovery/"><img src="<?php echo get_template_directory_uri() . '/images/sidebar/lincoln_sidebar_blue_bottom.png' ?>" alt="" loading="lazy"></a>
    </div>
</section>