<section class="newsletter_section">
    <div class="newsletter_container">
        <div class="newsletter_headline">
            <h3>SIGN UP FOR OUR NEWSLETTER</h3>
        </div>
        <div id="mc_embed_signup" class="newsletter_form_container">
            <form action="https://sunshinebh.us20.list-manage.com/subscribe/post?u=50abd3256ce6e9b74c656baf5&amp;id=59b1c25b91" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" novalidate>
                <div id="mc_embed_signup_scroll" class="news_letter_form_and_submit_container">
                    <input type="email" value="" name="EMAIL" class="email newsletter_email_input" id="mce-EMAIL" placeholder="email address" required>
                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_50abd3256ce6e9b74c656baf5_59b1c25b91" tabindex="-1" value=""></div>
                    <input type="submit" value="SUBSCRIBE" name="subscribe" id="mc-embedded-subscribe" class="newsletter_submit_button">
                </div>
            </form>
        </div>
    </div>
</section>