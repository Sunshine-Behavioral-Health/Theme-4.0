<section class="shortcode_phone_cta_section shortcode_section">
    <div class="shortcode_phone_cta_container">
        <div class="shortcode_phone_cta_body">
            <div class="shortcode_phone_cta_headline">
                <h4>Now is the time to seek help. Call us today.</h4>
            </div>

            <a id="phoneCta" class="invocaNumber phoneCta" href="tel:949-276-2886" onclick="dataLayer.push({'event': 'phone_click', 'shortcode_type' : 'phoneCta'});">949-276-2886</a>
        </div>
    </div>
</section>