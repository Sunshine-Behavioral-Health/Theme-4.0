<?php get_template_part('template-parts/javascript/graphTabs'); ?>

<section class="">
    <div class=>
        <h3><?php echo get_field('single_graph_headline_4') ?></h3>
    </div>
    <canvas id="line-chartFour" width="800" height="450"></canvas>
</section>


<?php get_template_part('template-parts/content/graph_data/individual_graph/graph_4'); ?>