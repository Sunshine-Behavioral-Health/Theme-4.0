<section class="sliding_form_shortcode_section">
    <div class="sliding_form_shortcode_container">
        <?php get_template_part('template-parts/forms/sliding_insurance_form'); ?>
    </div>
</section>