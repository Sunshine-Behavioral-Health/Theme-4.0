<section id="stateTable" class="state_table_section stateTable">
    <h4>Find an Addiction Treatment Resource in Your Home State</h4>

    <div class="state_table_wrapper">
        <div class="state_table_container">
            <div class="state_table_states_wrapper">
                <div class="state_table_element">
                    <a href="/alabama">Alabama</a>
                </div>

                <div class="state_table_element">
                    <a href="/alaska">Alaska</a>
                </div>

                <div class="state_table_element">
                    <a href="/arizona">Arizona</a>
                </div>

                <div class="state_table_element">
                    <a href="/arkansas">Arkansas</a>
                </div>

                <div class="state_table_element">
                    <a href="/california">California</a>
                </div>

                <div class="state_table_element">
                    <a href="/colorado">Colorado</a>
                </div>

                <div class="state_table_element">
                    <a href="/connecticut">Connecticut</a>
                </div>

                <div class="state_table_element">
                    <a href="/delaware">Delaware</a>
                </div>

                <div class="state_table_element">
                    <a href="/florida">Florida</a>
                </div>

                <div class="state_table_element">
                    <a href="/georgia">Georgia</a>
                </div>

                <div class="state_table_element">
                    <a href="/hawaii">Hawaii</a>
                </div>

                <div class="state_table_element">
                    <a href="/idaho">Idaho</a>
                </div>

                <div class="state_table_element">
                    <a href="/illinois">Illinois</a>
                </div>

                <div class="state_table_element">
                    <a href="/indiana">Indiana</a>
                </div>

                <div class="state_table_element">
                    <a href="/iowa">Iowa</a>
                </div>

                <div class="state_table_element">
                    <a href="/kansas">Kansas</a>
                </div>

                <div class="state_table_element">
                    <a href="/kentucky">Kentucky</a>
                </div>

                <div class="state_table_element">
                    <a href="/louisiana">Louisiana</a>
                </div>

                <div class="state_table_element">
                    <a href="/maine">Maine</a>
                </div>

                <div class="state_table_element">
                    <a href="/maryland">Maryland</a>
                </div>

                <div class="state_table_element">
                    <a href="/massachusetts">Massachusetts</a>
                </div>

                <div class="state_table_element">
                    <a href="/michigan">Michigan</a>
                </div>

                <div class="state_table_element">
                    <a href="/minnesota">Minnesota</a>
                </div>

                <div class="state_table_element">
                    <a href="/mississippi">Mississippi</a>
                </div>

                <div class="state_table_element">
                    <a href="/missouri">Missouri</a>
                </div>

                <div class="state_table_element">
                    <a href="/montana">Montana</a>
                </div>

                <div class="state_table_element">
                    <a href="/nebraska">Nebraska</a>
                </div>

                <div class="state_table_element">
                    <a href="/nevada">Nevada</a>
                </div>

                <div class="state_table_element">
                    <a href="/new-hampshire">New Hampshire</a>
                </div>

                <div class="state_table_element">
                    <a href="/new-jersey">New Jersey</a>
                </div>

                <div class="state_table_element">
                    <a href="/new-mexico">New Mexico</a>
                </div>

                <div class="state_table_element">
                    <a href="/new-york">New York</a>
                </div>

                <div class="state_table_element">
                    <a href="/north-carolina">North Carolina</a>
                </div>

                <div class="state_table_element">
                    <a href="/north-dakota">North Dakota</a>
                </div>

                <div class="state_table_element">
                    <a href="/ohio">Ohio</a>
                </div>

                <div class="state_table_element">
                    <a href="/oklahoma">Oklahoma</a>
                </div>

                <div class="state_table_element">
                    <a href="/oregon">Oregon</a>
                </div>

                <div class="state_table_element">
                    <a href="/pennsylvania">Pennsylvania</a>
                </div>

                <div class="state_table_element">
                    <a href="/rhode-island">Rhode Island</a>
                </div>

                <div class="state_table_element">
                    <a href="/south-carolina">South Carolina</a>
                </div>

                <div class="state_table_element">
                    <a href="/south-dakota">South Dakota</a>
                </div>

                <div class="state_table_element">
                    <a href="/tennessee">Tennessee</a>
                </div>

                <div class="state_table_element">
                    <a href="/texas">Texas</a>
                </div>

                <div class="state_table_element">
                    <a href="/utah">Utah</a>
                </div>

                <div class="state_table_element">
                    <a href="/vermont">Vermont</a>
                </div>

                <div class="state_table_element">
                    <a href="/virginia">Virginia</a>
                </div>

                <div class="state_table_element">
                    <a href="/washington">Washington</a>
                </div>

                <div class="state_table_element">
                    <a href="/west-virginia">West Virginia</a>
                </div>

                <div class="state_table_element">
                    <a href="/wisconsin">Wisconsin</a>
                </div>

                <div class="state_table_element">
                    <a href="/wyoming">Wyoming</a>
                </div>
            </div>
        </div>
    </div>
</section>