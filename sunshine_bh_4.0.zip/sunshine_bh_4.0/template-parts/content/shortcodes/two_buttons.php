<section class="desktop_buttons_section">
    <div class="desktop_buttons_container">
        <a href="tel:949-276-2886" id="mobileCtaPhone" class="invocaNumber button_one mobileCtaPhone" onclick="dataLayer.push({'event': 'phone_click', 'shortcode_type' : 'mobileCtaPhone'});">949-276-2886</a>
        <a class="button_two mobileCtaInsurance" href="https://www.sunshinebehavioralhealth.com/insurance/" onclick="dataLayer.push({'event': 'insurance_click', 'shortcode_type' : 'mobileCtaInsurance'});">Verify Insurance</a>

    </div>
	<div class="row line">
	<p>
		
	</p>
		</div>
</section>