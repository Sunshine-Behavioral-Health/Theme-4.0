<section class="two_cta_btn_sidebar_section">
    <div class="two_cta_btn_sidebar_container">
        <div class="two_cta_btn_sidebar_top_cta">
            <a href="tel:949-276-2886" id="twoCtaFixedSidebarPhone" class="invocaNumber twoCtaFixedSidebarPhone" onclick="dataLayer.push({'event': 'phone_click', 'shortcode_type' : 'twoCtaFixedSidebarPhone'});">949-276-2886</a>
        </div>
        <div class="two_cta_btn_sidebar_bottom_cta">
            <a href="https://sunshinebehavioralhealth.com/insurance/" class="twoCtaFixedSidebarInsurance" onclick="dataLayer.push({'event': 'insurance_click', 'shortcode_type' : 'twoCtaFixedSidebarInsurance'});">VERIFY INSURANCE</a>
        </div>
    </div>
</section>