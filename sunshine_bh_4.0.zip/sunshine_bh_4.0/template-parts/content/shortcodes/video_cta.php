<section class="short_code_video_cta shortcode_section">
    <div class="short_code_video">
        <h4 class="youtube_headline"><?php echo get_field('youtube_headline'); ?></h4>
        <?php echo get_field('youtube_src') ?>
    </div>
</section>