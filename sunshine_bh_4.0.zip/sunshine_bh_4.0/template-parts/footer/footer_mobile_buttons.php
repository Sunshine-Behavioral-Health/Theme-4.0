<section class="mobile_bottom_cta_section">
    <div class="mobile_bottom_cta_container">
        <a href="tel:949-276-2886" id="mobileCtaPhone" class="invocaNumber cta_left mobileCtaPhone" onclick="dataLayer.push({'event': 'phone_click', 'shortcode_type' : 'mobileCtaPhone'});">949-276-2886</a>
        <a class="cta_right mobileCtaInsurance" href="https://www.sunshinebehavioralhealth.com/insurance/" onclick="dataLayer.push({'event': 'insurance_click', 'shortcode_type' : 'mobileCtaInsurance'});">Verify Insurance</a>

        
    </div>
</section>