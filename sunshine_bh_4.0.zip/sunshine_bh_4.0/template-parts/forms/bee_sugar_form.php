<form class="bee_sugar_form_container" action="" autocomplete="off">
    <label for="firstName"></label>
    <input class="firstName" id="firstName" name="firstName" placeholder="First Name" type="text" autocomplete="off">

    <label for="lastName"></label>
    <input class="lastName" id="lastame" placeholder="Last Name" type="text" autocomplete="off">

    <label for="email"></label>
    <input class="email" id="email" placeholder="Email" type="email" autocomplete="off">

    <label for="phone"></label>
    <input class="phone" id="email" placeholder="Phone" type="tel" autocomplete="off">
</form>