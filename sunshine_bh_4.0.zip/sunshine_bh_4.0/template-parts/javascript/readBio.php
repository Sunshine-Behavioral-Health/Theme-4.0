<script>
    jQuery(document).ready(function($) {
        $(".read_more_button").click(function() {
            $(this).next().toggleClass("hide_bio");
        });
    });
</script>

<?php
